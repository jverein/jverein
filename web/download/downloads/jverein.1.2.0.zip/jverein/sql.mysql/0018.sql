alter table buchung modify column  kommentar varchar(1000);
  