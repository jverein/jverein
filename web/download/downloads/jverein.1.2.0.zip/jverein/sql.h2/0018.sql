alter table buchung alter column  kommentar varchar(1000);
  