ALTER TABLE lehrgang DROP CONSTRAINT fkLehrgang1;

  