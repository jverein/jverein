ALTER TABLE mitglied ALTER COLUMN titel varchar(10);
ALTER TABLE mitglied ALTER COLUMN plz   varchar(10);