CREATE INDEX ixAbrechnung1 ON abrechnung(mitglied);
